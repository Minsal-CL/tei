# Eventos - Tiempos de Espera Interoperable v0.2.3

* [**Table of Contents**](toc.md)
* **Eventos**

## Eventos

### Tabla de códigos de Eventos

| | | | |
| :--- | :--- | :--- | :--- |
| iniciar | Iniciar | Ocurre cuando un usuario acude a su Centro de Atención Primaria (APS) a consulta médica, de odontología, matronería, consulta oftalmológica con tecnólogo/a médico/a y el profesional de salud que lo atiende, genera la solicitud de interconsulta (SIC) para nueva consulta de especialidad en el nivel secundario. | La respuesta debe indicar si hay errores o indicar que la interconsulta ha sido creada |
| referenciar | Referenciar | Corresponde al acto de asignación del establecimiento de nivel secundario de destino de la SIC (al cual se está derivando). Puede ser accionado por el mismo profesional que solicitó la interconsulta, por el algoritmo del Registro Clínico Electrónico o por el equipo gestor local de solicitudes de interconsulta. Puede ocurrir simultáneamente cuando se genera la solicitud de interconsulta (al mismo tiempo que el evento INICIAR) o en un tiempo diferido. Este destino se establece de acuerdo al protocolo de referencia y contrarreferencia para el problema específico de salud (mapa de derivación). En algunos casos, dependiendo de los procedimientos locales del establecimiento de Atención Primaria de Salud, se completará información y antecedentes faltantes de la solicitud de Interconsulta. | La respuesta debe indicar si hay errores o indicar que la interconsulta ha sido referenciada |
| revisar | Revisar | Un profesional clínico contralor debe revisar la pertinencia de la solicitud, según el protocolo de referencia y contrarreferencia establecido y reconocido por la red. También puede objetar la derivación por falta de antecedentes y gestionar la completitud de los antecedentes clínicos y administrativos. Esto puede suceder en APS o nivel secundario según acuerdo entre ambos niveles y el Servicio de Salud, debiendo existir un flujo definido en caso de rechazo de la SIC para dar respuesta al usuario. Acá se pueden verificar si existe alguna causal de salida de Lista de Espera, por ejemplo, en caso de defunción, GES, no beneficiario, entre otras. | La respuesta debe indicar si errores hay o indicar que la interconsulta ha sido revisada |
| priorizar | Priorizar | Un profesional clínico debe realizar la priorización de la solicitud de interconsulta, en función de la categorización definida, considerando patología, gravedad y determinantes sociales del paciente. Esto puede suceder en el establecimiento de Atención Primaria de Salud o nivel secundario según acuerdo entre ambos niveles y el Servicio de Salud. Acá se pueden verificar si existe alguna causa de salida de Lista de Espera, por ejemplo, en caso de defunción, GES, no beneficiario, entre otras. (Según[Norma Técnica N°118](https://drive.google.com/file/d/1kZBAY7E-Rmy3DxGCMP3emotxEWh5nLEy/view)) | La respuesta debe indicar si hay errores o indicar que la interconsulta ha sido priorizada |
| agendar | Agendar | Un funcionario administrativo contactará al usuario para agendar la cita con el especialista según la priorización asignada y la disponibilidad de horas. Esto puede suceder tanto en el establecimiento de atención primaria como en el nivel secundario según acuerdo entre ambos niveles y el Servicio de Salud. Acá se pueden verificar si existe alguna causa de salida de Lista de Espera. | La respuesta debe indicar si hay errores o indicar que la interconsulta ha sido agendada con el paciente |
| atender | Atender | El usuario recibe atención con el médico especialista en el establecimiento de nivel secundario. El médico especialista tendrá a la vista los datos de la Solicitud de Interconsulta generada en el establecimiento de nivel primario en la Ficha Clínica Electrónica local, y en esa misma plataforma registrará los datos del encuentro (solicitud de exámenes, indicaciones, tratamiento, reposo, etc.). Esta información quedará disponible para intercambiarse con otros sistemas de información, como el registro clínico del establecimiento de atención primaria o el Portal Paciente. El usuario puede quedar en control, hospitalizado o ser dado de alta. En estos tres casos el paciente sale de la Lista de Espera. | La respuesta debe indicar si hay errores o indicar que la interconsulta se ha llevado a cabao con el paciente |
| terminar | Terminar | En este acto el paciente sale de la Lista de Espera, ya sea porque fue atendido o por alguna de las causales de salida de la Lista de Espera según la[Norma Técnica N°118](https://drive.google.com/file/d/1kZBAY7E-Rmy3DxGCMP3emotxEWh5nLEy/view). Esto puede ocurrir de forma automática por definiciones del sistema informático, o mediante un funcionario administrativo. | La respuesta debe indicar si hay errores o indicar que la interconsulta ha sido terminada |

### Definición de Transacciones relacionados a eventos

* [Transacción Evento Iniciar](Transacciones.md#transacci%C3%B3n-evento-iniciar)
* [Transacción Evento Referenciar](Transacciones.md#transacci%C3%B3n-evento-referenciar)
* [Transacción Evento Revisar](Transacciones.md#transacci%C3%B3n-evento-revisar)
* [Transacción Evento Priorizar](Transacciones.md#transacci%C3%B3n-evento-priorizar)
* [Transacción Evento Agendar](Transacciones.md#transacci%C3%B3n-evento-agendar)
* [Transacción Evento Atender](Transacciones.md#transacci%C3%B3n-evento-atender)
* [Transacción Evento Terminar](Transacciones.md#transacci%C3%B3n-evento-terminar)

