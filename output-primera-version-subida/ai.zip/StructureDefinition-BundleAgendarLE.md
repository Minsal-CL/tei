# Bundle Agendar LE - Tiempos de Espera Interoperable v0.2.3

* [**Table of Contents**](toc.md)
* [**Artifacts**](artifacts.md)
* **Bundle Agendar LE**

## Resource Profile: Bundle Agendar LE 

| | | |
| :--- | :--- | :--- |
| *Official URL*:https://interoperabilidad.minsal.cl/fhir/ig/tei/StructureDefinition/BundleAgendarLE | *Version*:0.2.3 | |
| * Standards status: *[Draft](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 0 | *Computable Name*:BundleAgendarLE |

 
Bundle Agendar LE, recurso utilizado para transportar todos los datos del mensaje relacionado al evento Agendar. 

### Consideraciones Generales

* En el recurso [MessageHeader](StructureDefinition-MessageHeaderLE.md) el elemento eventCoding.code su valor debe ser "agendar".
* El rol que cumple el profesional en este evento es de "agendador".
* El recurso [Appointment](StructureDefinition-AppointmentAgendarLE.md) debe ser agregado en MessageHeader.focus.

**Usages:**

* This Profile is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/hl7.fhir.cl.minsal.tei|current/StructureDefinition/StructureDefinition-BundleAgendarLE.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-BundleAgendarLE.csv), [Excel](StructureDefinition-BundleAgendarLE.xlsx), [Schematron](StructureDefinition-BundleAgendarLE.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "BundleAgendarLE",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 0
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "draft"
  }],
  "url" : "https://interoperabilidad.minsal.cl/fhir/ig/tei/StructureDefinition/BundleAgendarLE",
  "version" : "0.2.3",
  "name" : "BundleAgendarLE",
  "title" : "Bundle Agendar LE",
  "status" : "draft",
  "date" : "2026-07-22T14:55:14-04:00",
  "publisher" : "Unidad de Interoperabilidad - MINSAL",
  "contact" : [{
    "name" : "Unidad de Interoperabilidad - MINSAL",
    "telecom" : [{
      "system" : "url",
      "value" : "https://interoperabilidad.minsal.cl"
    }]
  },
  {
    "name" : "Jorge Mansilla",
    "telecom" : [{
      "system" : "email",
      "value" : "jorge.mansilla@minsal.cl",
      "use" : "work"
    }]
  }],
  "description" : "Bundle Agendar LE, recurso utilizado para transportar todos los datos del mensaje relacionado al evento Agendar.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "CL",
      "display" : "Chile"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "cda",
    "uri" : "http://hl7.org/v3/cda",
    "name" : "CDA (R2)"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Bundle",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Bundle",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Bundle",
      "path" : "Bundle"
    },
    {
      "id" : "Bundle.id",
      "path" : "Bundle.id",
      "short" : "Id propio del recurso",
      "mustSupport" : true
    },
    {
      "id" : "Bundle.type",
      "path" : "Bundle.type",
      "short" : "Indica de qué tipo es el Bundle, en este caso de tipo message",
      "patternCode" : "message",
      "mustSupport" : true
    },
    {
      "id" : "Bundle.timestamp",
      "path" : "Bundle.timestamp",
      "short" : "Cuando el Bundle fue armado",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Bundle.entry",
      "path" : "Bundle.entry",
      "slicing" : {
        "discriminator" : [{
          "type" : "profile",
          "path" : "resource"
        }],
        "rules" : "closed"
      },
      "short" : "Entrada en el Bundle: contendrá un recurso o información",
      "min" : 8,
      "max" : "8",
      "mustSupport" : true
    },
    {
      "id" : "Bundle.entry:messageheader",
      "path" : "Bundle.entry",
      "sliceName" : "messageheader",
      "short" : "Entrada en el Bundle: contendrá un recurso MessageHeader",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Bundle.entry:messageheader.fullUrl",
      "path" : "Bundle.entry.fullUrl",
      "short" : "Uri de identificación dentro del Bundle",
      "mustSupport" : true
    },
    {
      "id" : "Bundle.entry:messageheader.resource",
      "path" : "Bundle.entry.resource",
      "short" : "Cabecera del mensaje que facilita el seguimiento, debe ser siempre el primer entry en Bundle.type = message",
      "min" : 1,
      "type" : [{
        "code" : "MessageHeader",
        "profile" : ["https://interoperabilidad.minsal.cl/fhir/ig/tei/StructureDefinition/MessageHeaderLE"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Bundle.entry:servicerequest",
      "path" : "Bundle.entry",
      "sliceName" : "servicerequest",
      "short" : "Entrada en el Bundle: contendrá un recurso ServiceRequest",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Bundle.entry:servicerequest.fullUrl",
      "path" : "Bundle.entry.fullUrl",
      "short" : "Uri de identificación dentro del Bundle",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Bundle.entry:servicerequest.resource",
      "path" : "Bundle.entry.resource",
      "short" : "Prestación que se requiere para el paciente, que no pudo ser resuelta en el APS",
      "min" : 1,
      "type" : [{
        "code" : "ServiceRequest",
        "profile" : ["https://interoperabilidad.minsal.cl/fhir/ig/tei/StructureDefinition/ServiceRequestLE"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Bundle.entry:practitionerAdministrativo",
      "path" : "Bundle.entry",
      "sliceName" : "practitionerAdministrativo",
      "short" : "Entrada en el Bundle: contendrá un recurso Practitioner",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Bundle.entry:practitionerAdministrativo.fullUrl",
      "path" : "Bundle.entry.fullUrl",
      "short" : "Uri de identificación dentro del Bundle",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Bundle.entry:practitionerAdministrativo.resource",
      "path" : "Bundle.entry.resource",
      "short" : "Profesional que agenda la interconsulta",
      "min" : 1,
      "type" : [{
        "code" : "Practitioner",
        "profile" : ["https://interoperabilidad.minsal.cl/fhir/ig/tei/StructureDefinition/PractitionerAdministrativoLE"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Bundle.entry:practitionerProfesional",
      "path" : "Bundle.entry",
      "sliceName" : "practitionerProfesional",
      "short" : "Entrada en el Bundle: contendrá un recurso Practitioner",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Bundle.entry:practitionerProfesional.fullUrl",
      "path" : "Bundle.entry.fullUrl",
      "short" : "Uri de identificación dentro del Bundle",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Bundle.entry:practitionerProfesional.resource",
      "path" : "Bundle.entry.resource",
      "short" : "Profesional que atendera la interconsulta",
      "min" : 1,
      "type" : [{
        "code" : "Practitioner",
        "profile" : ["https://interoperabilidad.minsal.cl/fhir/ig/tei/StructureDefinition/PractitionerProfesionalLE"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Bundle.entry:practitionerRole",
      "path" : "Bundle.entry",
      "sliceName" : "practitionerRole",
      "short" : "Entrada en el Bundle: contendrá un recurso PractitionerRole",
      "min" : 2,
      "max" : "2",
      "mustSupport" : true
    },
    {
      "id" : "Bundle.entry:practitionerRole.fullUrl",
      "path" : "Bundle.entry.fullUrl",
      "short" : "Uri de identificación dentro del Bundle",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Bundle.entry:practitionerRole.resource",
      "path" : "Bundle.entry.resource",
      "short" : "Se indica el administrativo y organización que agenda la interconsulta, o el profesional que realizará la atención",
      "min" : 1,
      "type" : [{
        "code" : "PractitionerRole",
        "profile" : ["https://interoperabilidad.minsal.cl/fhir/ig/tei/StructureDefinition/PractitionerRoleLE"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Bundle.entry:organization",
      "path" : "Bundle.entry",
      "sliceName" : "organization",
      "short" : "Entrada en el Bundle: contendrá un recurso Organization",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Bundle.entry:organization.fullUrl",
      "path" : "Bundle.entry.fullUrl",
      "short" : "Uri de identificación dentro del Bundle",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Bundle.entry:organization.resource",
      "path" : "Bundle.entry.resource",
      "short" : "Centro de salud que agenda y atiende la interconsulta",
      "min" : 1,
      "type" : [{
        "code" : "Organization",
        "profile" : ["https://interoperabilidad.minsal.cl/fhir/ig/tei/StructureDefinition/OrganizationLE"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Bundle.entry:appointment",
      "path" : "Bundle.entry",
      "sliceName" : "appointment",
      "short" : "Entrada en el Bundle: contendrá un recurso Appointment",
      "min" : 1,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Bundle.entry:appointment.fullUrl",
      "path" : "Bundle.entry.fullUrl",
      "short" : "Uri de identificación dentro del Bundle",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Bundle.entry:appointment.resource",
      "path" : "Bundle.entry.resource",
      "short" : "Recurso donde se indica el agendamiento para la atención del paciente.",
      "min" : 1,
      "type" : [{
        "code" : "Appointment",
        "profile" : ["https://interoperabilidad.minsal.cl/fhir/ig/tei/StructureDefinition/AppointmentAgendarLE"]
      }],
      "mustSupport" : true
    }]
  }
}

```
