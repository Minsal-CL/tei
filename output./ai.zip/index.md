# Index - Tiempos de Espera Interoperable v0.2.2

* [**Table of Contents**](toc.md)
* **Index**

## Index

| | |
| :--- | :--- |
| *Official URL*:https://interoperabilidad.minsal.cl/fhir/ig/tei/ImplementationGuide/hl7.fhir.cl.minsal.tei | *Version*:0.2.2 |
| Draft as of 2026-04-29 | *Computable Name*:TiemposdeEsperaInteroperable |

### Alcance

Esta guía de implementación aborda el proceso de solicitud de interconsulta (SIC), para consulta nueva de especialidad No GES desde el nivel primario de salud (APS) al nivel secundario, mediante la plataforma interoperable de Tiempos de Espera. Para representar este proceso se definen 7 eventos, los cuáles son:

* Iniciar: Generación de SIC en box de APS
* Referenciar: Asignacion de destino desde la APS
* Revisar: Revisión de la pertinencia
* Priorizar: Asignación o revisión de la prioridad
* Agendar: Agendamiento de la cita
* Atender: Atención en consulta con el especialista
* Terminar: Egreso de la Lista de Espera

### Introducción

#### Antecedentes

El sistema de salud en Chile se estructura en niveles (primario, secundario y terciario), siendo el nivel primario el con mayor despliegue en el territorio, con atenciones de menor complejidad y la puerta de entrada a todas las atenciones de salud en la red pública de establecimientos. Para optar a una atención de especialidad, las personas deben ser derivadas desde la atención primaria a un centro de mayor complejidad, teniendo que esperar para recibir esta atención en el nivel secundario o terciario.

Las personas y tiempos que deben esperar para una atención de salud han sido y son una preocupación para todo el sistema sanitario.

Los sistemas que soportan actualmente la información de las personas y tiempos de espera por su estructura y forma de operar, no permiten conocer la realidad de la situación, trazar al paciente y tampoco permite mantener informado al paciente. Para mejorar la gestión de la red asistencial y la coordinación entre sus niveles, se requiere implementar un proceso interoperable de solicitud de nueva consulta de especialidad desde APS a nivel secundario, para patologías no adscritas a las garantías explícitas de salud (GES).

#### Descripción

Se propone desarrollar un sistema de información que permita hacer trazabilidad del proceso desde que se solicita interconsulta para Nueva atención de Especialidad, hasta que se atiende en atención secundaria, dejando disponible esta información tanto para el paciente, como para los establecimientos de salud involucrados y el nivel central para la toma de decisiones y mejor gestión de los recursos.

Este proyecto fue ejecutado por un equipo multidisciplinario del Ministerio de Salud, con la participación de profesionales del Departamento de Estadísticas e Información en Salud (DEIS), la División de Gestión de la Red Asistencial (DIGERA), la División de Atención Primaria (DIVAP) y la Unidad de Interoperabilidad del Departamento de Tecnologías de la Información y Comunicaciones (DTIC), con el apoyo del Centro Nacional de Sistemas de Información en Salud (CENS). Se ha utilizado una metodología para el re-diseño del proceso, optimizándolo y centrándolo en el paciente y se ha implementado bajo el uso estándares internacionales de interoperabilidad.

### Objetivos del Proyecto de Tiempos de Espera Interoperables

#### General

Desarrollar un sistema seguro e interoperable de datos clínicos que respalde la gestión de información, incluyendo su registro, transferencia y análisis. Dicha información es entregada a través de una plataforma que facilite su acceso de manera precisa y de calidad, en el contexto de las solicitudes de nueva consulta de especialidad No GES para pacientes de la red asistencial.

#### Específicos

* Lograr el intercambio de información de las solicitudes de interconsultas emitidas desde los registros clínicos electrónicos implementados en los establecimientos de salud pública del país y la plataforma de interoperabilidad de MINSAL.
* Promover la estandarización de los datos involucrados en este proceso.
* Proporcionar directrices y reglas comunes que faciliten la adopción de estándares de interoperabilidad semánticos y sintácticos, tanto por parte de profesionales clínicos como para los desarrolladores en toda la red asistencial.
* Garantizar que los datos se representen y se compartan de manera coherente entre sistemas, evitando ambigüedades y errores en la interpretación de la información.

### Objetivos de la Guía de Implementación

#### General

Brindar las directrices para el desarrollo de sistema de información que garanticen la interoperabilidad con la plataforma de Tiempos de Espera para el proceso de solicitud de nueva consulta de especialidad desde APS a nivel secundario, según los estándares definidos por el Ministerio de Salud.

#### Específicos

* Otorgar las herramientas necesarias para el desarrollo de sistemas informáticos de registro clínico que interoperen con la plataforma de tiempos de espera, en base al estándar HL7 FHIR.
* Describir los distintos perfiles de usuario del proceso de solicitud de interconsulta de primera atención de especialidad no GES y los recursos asociados a cada uno.
* Ejemplificar los distintos casos de uso asociados al proceso de tiempos de espera para solicitud de primera consulta de especialidad desde APS a nivel secundario.

### Perfiles Globales

*There are no Global profiles defined*

### Dependencias





### Analisis de versiones cruzadas

This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (hl7.fhir.cl.minsal.tei.r4)](package.r4.tgz) and [R4B (hl7.fhir.cl.minsal.tei.r4b)](package.r4b.tgz) are available.

### Declaracion de propiedad intelectual

This publication includes IP covered under the following statements.

* All content on ISO Online is copyright protected. The copyright is owned by ISO. Any use of the content, including copying of it in whole or in part, for example to another Internet site, is prohibited and would require written permission from ISO.

* [Códigos de Países](https://hl7chile.cl/fhir/ig/clcore/1.9.2/CodeSystem-CodPais.html): [PaisOrigenMPI](StructureDefinition-PaisOrigenMPI.md)


* ISO maintains the copyright on the country codes, and controls its use carefully. For further details see the ISO 3166 web page: [https://www.iso.org/iso-3166-country-codes.html](https://www.iso.org/iso-3166-country-codes.html)

* [ISO 3166-1 Codes for the representation of names of countries and their subdivisions — Part 1: Country code](http://terminology.hl7.org/6.1.0/CodeSystem-ISO3166Part1.html): [AllergyIntoleranceIniciarLE](StructureDefinition-AllergyIntoleranceIniciarLE.md), [AppointmentAgendarLE](StructureDefinition-AppointmentAgendarLE.md)... Show 109 more, [BundleAgendarLE](StructureDefinition-BundleAgendarLE.md), [BundleAtenderLE](StructureDefinition-BundleAtenderLE.md), [BundleIniciarLE](StructureDefinition-BundleIniciarLE.md), [BundlePriorizarLE](StructureDefinition-BundlePriorizarLE.md), [BundleReferenciarLE](StructureDefinition-BundleReferenciarLE.md), [BundleRevisarLE](StructureDefinition-BundleRevisarLE.md), [BundleTerminarLE](StructureDefinition-BundleTerminarLE.md), [CSConsecuenciaAtencionCodigo](CodeSystem-CSConsecuenciaAtencionCodigo.md), [CSDerivadoParaCodigo](CodeSystem-CSDerivadoParaCodigo.md), [CSDestinoReferenciaCodigo](CodeSystem-CSDestinoReferenciaCodigo.md), [CSEspecialidadBioqca](CodeSystem-CSEspecialidadBioqca.md), [CSEspecialidadFarma](CodeSystem-CSEspecialidadFarma.md), [CSEspecialidadMed](CodeSystem-CSEspecialidadMed.md), [CSEspecialidadOdont](CodeSystem-CSEspecialidadOdont.md), [CSEstablecimientoDestino](CodeSystem-CSEstablecimientoDestino.md), [CSEstadoCivil](CodeSystem-CSEstadoCivil.md), [CSEstadoInterconsulta](CodeSystem-CSEstadoInterconsulta.md), [CSIndicecomorbilidad](CodeSystem-CSIndicecomorbilidad.md), [CSMediodeContacto](CodeSystem-CSMediodeContacto.md), [CSModalidadAtencionCodigo](CodeSystem-CSModalidadAtencionCodigo.md), [CSMotivoCierreInterconsulta](CodeSystem-CSMotivoCierreInterconsulta.md), [CSMotivoNoContactabilidad](CodeSystem-CSMotivoNoContactabilidad.md), [CSMotivoNoPertinenciaCodigo](CodeSystem-CSMotivoNoPertinenciaCodigo.md), [CSPertinenciaInterconsulta](CodeSystem-CSPertinenciaInterconsulta.md), [CSPractitionerTipoRolLE](CodeSystem-CSPractitionerTipoRolLE.md), [CSReligion](CodeSystem-CSReligion.md), [CSTipoConsulta](CodeSystem-CSTipoConsulta.md), [CSTipoEventoLE](CodeSystem-CSTipoEventoLE.md), [CSTipoObservacionMinsal](CodeSystem-CSTipoObservacionMinsal.md), [CSTituloProfesional](CodeSystem-CSTituloProfesional.md), [CSorigenInterconsulta](CodeSystem-CSorigenInterconsulta.md), [CarePlanAtenderLE](StructureDefinition-CarePlanAtenderLE.md), [CodigoExamen](ValueSet-CodigoExamen.md), [ConditionDiagnosticoLE](StructureDefinition-ConditionDiagnosticoLE.md), [EncounterAtenderLE](StructureDefinition-EncounterAtenderLE.md), [EncounterIniciarLE](StructureDefinition-EncounterIniciarLE.md), [ExtensionBoolAtencionPreferente](StructureDefinition-ExtensionBoolAtencionPreferente.md), [ExtensionBoolRequiereExamen](StructureDefinition-ExtensionBoolRequiereExamen.md), [ExtensionBoolResolutividadAPS](StructureDefinition-ExtensionBoolResolutividadAPS.md), [ExtensionConsecuenciaAtencionCodigo](StructureDefinition-ExtensionConsecuenciaAtencionCodigo.md), [ExtensionContactadoLE](StructureDefinition-Contactado.md), [ExtensionEspecialidadMedicaDestinoCodigo](StructureDefinition-ExtensionEspecialidadMedicaDestinoCodigo.md), [ExtensionEstadoInterconsultaCodigoLE](StructureDefinition-ExtensionEstadoInterconsultaCodigoLE.md), [ExtensionMediodeContacto](StructureDefinition-ExtensionMediodeContacto.md), [ExtensionMotivoCierreInterconsulta](StructureDefinition-ExtensionMotivoCierreInterconsulta.md), [ExtensionMotivoNoPertinencia](StructureDefinition-ExtensionMotivoNoPertinencia.md), [ExtensionOrigenInterconsulta](StructureDefinition-ExtensionOrigenInterconsulta.md), [ExtensionPertinenciaAtencionBox](StructureDefinition-ExtensionPertinenciaAtencionBox.md), [ExtensionPertinenciaInterconsulta](StructureDefinition-ExtensionPertinenciaInterconsulta.md), [ExtensionSolicitudExamenes](StructureDefinition-ExtensionSolicitudExamenes.md), [ExtensionStringFundamentoPriorizacion](StructureDefinition-ExtensionStringFundamentoPriorizacion.md), [ExtensionSubEspecialidadMedicaDestinoCodigo](StructureDefinition-ExtensionSubEspecialidadMedicaDestinoCodigo.md), [MedicationRequestLE](StructureDefinition-MedicationRequestLE.md), [Mencion](StructureDefinition-Mencion.md), [MessageHeaderLE](StructureDefinition-MessageHeaderLE.md), [ObservationAnamnesisLE](StructureDefinition-ObservationAnamnesisLE.md), [ObservationDiscapacidadLE](StructureDefinition-ObservationDiscapacidadLE.md), [ObservationIndiceComorbilidadLE](StructureDefinition-ObservationIndiceComorbilidadLE.md), [ObservationIniciarCuidadorLE](StructureDefinition-ObservationIniciarCuidadorLE.md), [ObservationResultadoExamen](StructureDefinition-ObservationResultadoExamen.md), [OrganizationLE](StructureDefinition-OrganizationLE.md), [PaisOrigenMPI](StructureDefinition-PaisOrigenMPI.md), [PatientLE](StructureDefinition-PatientLE.md), [PractitionerAdministrativoLE](StructureDefinition-PractitionerAdministrativoLE.md), [PractitionerProfesionalLE](StructureDefinition-PractitionerProfesionalLE.md), [PractitionerRoleLE](StructureDefinition-PractitionerRoleLE.md), [ProblemaSaludGESCS](CodeSystem-cs-problema-ges-tei.md), [ProblemaSaludGESVS](ValueSet-vs-problema-ges-tei.md), [PueblosAfrodescendiente](StructureDefinition-PueblosAfrodescendiente.md), [PueblosOriginarios](StructureDefinition-PueblosOriginarios.md), [PueblosOriginariosCS](CodeSystem-PueblosOriginariosCS.md), [PueblosOriginariosPerteneciente](StructureDefinition-PueblosOriginariosPerteneciente.md), [PueblosOriginariosVS](ValueSet-PueblosOriginariosVS.md), [Questionnaire/MotivoDerivacion](Questionnaire-MotivoDerivacion.md), [QuestionnaireResponseIniciarLE](StructureDefinition-QuestionnaireResponseIniciarLE.md), [Religion](StructureDefinition-Religion.md), [ServiceRequestExamenLE](StructureDefinition-ServiceRequestExamenLE.md), [ServiceRequestLE](StructureDefinition-ServiceRequestLE.md), [SituacionCalle](StructureDefinition-SituacionCalle.md), [SospechaPatologiaGes](StructureDefinition-SospechaPatologiaGes.md), [TiemposdeEsperaInteroperable](index.md), [TipoDeObservacion](ValueSet-TipoDeObservacion.md), [VSConsecuenciaAtencionCodigo](ValueSet-VSConsecuenciaAtencionCodigo.md), [VSDerivadoParaCodigo](ValueSet-VSDerivadoParaCodigo.md), [VSDestinoReferenciaCodigo](ValueSet-VSDestinoReferenciaCodigo.md), [VSEspecialidadBioqca](ValueSet-VSEspecialidadBioqca.md), [VSEspecialidadFarma](ValueSet-VSEspecialidadFarma.md), [VSEspecialidadMed](ValueSet-VSEspecialidadMed.md), [VSEspecialidadOdont](ValueSet-VSEspecialidadOdont.md), [VSEstablecimientoDestino](ValueSet-VSEstablecimientoDestino.md), [VSEstadoCivil](ValueSet-VSEstadoCivil.md), [VSEstadoInterconsulta](ValueSet-VSEstadoInterconsulta.md), [VSIdentificadorPrestador](ValueSet-VSIdentificadorPrestador.md), [VSIndicecomorbilidad](ValueSet-VSIndicecomorbilidad.md), [VSMediodeContacto](ValueSet-VSMediodeContacto.md), [VSModalidadAtencionCodigo](ValueSet-VSModalidadAtencionCodigo.md), [VSMotivoCierreInterconsulta](ValueSet-VSMotivoCierreInterconsulta.md), [VSMotivoNoContactabilidad](ValueSet-VSMotivoNoContactabilidad.md), [VSMotivoNoPertinenciaCodigo](ValueSet-VSMotivoNoPertinenciaCodigo.md), [VSPertinenciaInterconsulta](ValueSet-VSPertinenciaInterconsulta.md), [VSPractitionerTipoRolLE](ValueSet-VSPractitionerTipoRolLE.md), [VSReligion](ValueSet-VSReligion.md), [VSServicioRequerido](ValueSet-VSServicioRequerido.md), [VSTerminologiasDiag](ValueSet-VSTerminologiasDiag.md), [VSTipoConsulta](ValueSet-VSTipoConsulta.md), [VSTipoEventoLE](ValueSet-VSTipoEventoLE.md), [VSTituloProfesional](ValueSet-VSTituloProfesional.md), [VSorigenInterconsulta](ValueSet-VSorigenInterconsulta.md) and [VsEspecialidadDest](ValueSet-VsEspecialidadDest.md)


* This material contains content from [LOINC](http://loinc.org). LOINC is copyright © 1995-2020, Regenstrief Institute, Inc. and the Logical Observation Identifiers Names and Codes (LOINC) Committee and is available at no cost under the [license](http://loinc.org/license). LOINC® is a registered United States trademark of Regenstrief Institute, Inc.

* [LOINC](http://terminology.hl7.org/6.1.0/CodeSystem-v3-loinc.html): [CodigoExamen](ValueSet-CodigoExamen.md), [ObservationAnamnesisLE](StructureDefinition-ObservationAnamnesisLE.md)... Show 6 more, [ObservationDiscapacidadLE](StructureDefinition-ObservationDiscapacidadLE.md), [ObservationIndiceComorbilidadLE](StructureDefinition-ObservationIndiceComorbilidadLE.md), [ObservationIniciarCuidadorLE](StructureDefinition-ObservationIniciarCuidadorLE.md), [ObservationResultadoExamen](StructureDefinition-ObservationResultadoExamen.md), [ServiceRequestExamenLE](StructureDefinition-ServiceRequestExamenLE.md) and [TipoDeObservacion](ValueSet-TipoDeObservacion.md)


* This material contains content that is copyright of SNOMED International. Implementers of these specifications must have the appropriate SNOMED CT Affiliate license - for more information contact [https://www.snomed.org/get-snomed](https://www.snomed.org/get-snomed) or [info@snomed.org](mailto:info@snomed.org).

* [SNOMED Clinical Terms&reg; (SNOMED CT&reg;)](http://hl7.org/fhir/R4/codesystem-snomedct.html): [AllergyIntoleranceIniciarLE](StructureDefinition-AllergyIntoleranceIniciarLE.md), [ConditionDiagnosticoLE](StructureDefinition-ConditionDiagnosticoLE.md)... Show 8 more, [ObservationAnamnesisLE](StructureDefinition-ObservationAnamnesisLE.md), [ObservationDiscapacidadLE](StructureDefinition-ObservationDiscapacidadLE.md), [ObservationIndiceComorbilidadLE](StructureDefinition-ObservationIndiceComorbilidadLE.md), [ObservationIniciarCuidadorLE](StructureDefinition-ObservationIniciarCuidadorLE.md), [ServiceRequestLE](StructureDefinition-ServiceRequestLE.md), [TipoDeObservacion](ValueSet-TipoDeObservacion.md), [VSServicioRequerido](ValueSet-VSServicioRequerido.md) and [VSTerminologiasDiag](ValueSet-VSTerminologiasDiag.md)


* This material derives from the HL7 Terminology (THO). THO is copyright ©1989+ Health Level Seven International and is made available under the CC0 designation. For more licensing information see: [https://terminology.hl7.org/license.html](https://terminology.hl7.org/license.html)

* [Condition Clinical Status Codes](http://terminology.hl7.org/6.1.0/CodeSystem-condition-clinical.html): [ConditionDiagnosticoLE](StructureDefinition-ConditionDiagnosticoLE.md)
* [ConditionVerificationStatus](http://terminology.hl7.org/6.1.0/CodeSystem-condition-ver-status.html): [ConditionDiagnosticoLE](StructureDefinition-ConditionDiagnosticoLE.md)
* [Observation Category Codes](http://terminology.hl7.org/6.1.0/CodeSystem-observation-category.html): [ObservationIndiceComorbilidadLE](StructureDefinition-ObservationIndiceComorbilidadLE.md)


* Usado con el permiso de HL7 International, todos los derechos resevados en los Licencias de HL7 Internacional.

* [Tipo Identificador](https://hl7chile.cl/fhir/ig/clcore/1.9.2/CodeSystem-CSTipoIdentificador.html): [PatientLE](StructureDefinition-PatientLE.md), [PractitionerAdministrativoLE](StructureDefinition-PractitionerAdministrativoLE.md), [PractitionerProfesionalLE](StructureDefinition-PractitionerProfesionalLE.md) and [VSIdentificadorPrestador](ValueSet-VSIdentificadorPrestador.md)


