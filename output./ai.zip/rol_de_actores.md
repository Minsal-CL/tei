# Rol De Actores - Tiempos de Espera Interoperable v0.2.2

* [**Table of Contents**](toc.md)
* **Rol De Actores**

## Rol De Actores

### Iniciador

Corresponde al profesional de la salud que se encuentra atendiendo al usuario (paciente) en la consulta que puede ser médica, de odontología, matronería o consulta oftalmológica con tecnólogo/a médico/a, y que en virtud a su evaluación y cuando corresponda, origina la Solicitud de Interconsulta (SIC) para nueva consulta de especialidad hacia el nivel secundario.

Los profesionales autorizados para iniciar este proceso son médicos/as, matrones/as, odontólogo/as o tecnólogos/as médicos/as con mención en oftalmología. Este profesional deberá completar los antecedentes clínicos que fundamente la decisión de derivar a especialidad.

### Referenciador

Corresponde al funcionario/a del establecimiento de salud de nivel primario que asigna el establecimiento de nivel secundario de destino de la SIC (al cual se está derivando), en función del protocolo de referencia y contrarreferencia definido para el problema específico de salud y la especialidad (mapa de derivación), establecido y reconocido por la red. Esta función no está limitada a profesionales de la salud.

Puede ser el mismo profesional que solicitó la interconsulta, puede ser un/a funcionario/a del equipo gestor local de solicitudes de interconsulta o en algunos casos, no ser mediado por una persona, si no que se asigna automáticamente por un algoritmo del Registro Clínico Electrónico. En algunos casos, dependiendo de los procedimientos locales del establecimiento de Atención Primaria de Salud, este/a funcionario/a también completará información y antecedentes faltantes de la solicitud de Interconsulta

### Revisor

Es el/la profesional clínico/a que ejerce las funciones de contraloría, quien revisa la pertinencia de la solicitud, según el protocolo de referencia y contrarreferencia establecido y reconocido por la red y los antecedentes entregados por el INICIADOR. Puede aprobar, rechazar u objetar la derivación por falta de antecedentes y gestionar la completitud de las antecedentes clínicos y administrativos.

Este profesional pertenece al establecimiento de atención primaria. en caso de rechazar la SIC, debe gestionar las acciones necesarias para dar respuesta al usuario (paciente).

El REVISOR también pueden verificar si existe alguna causal de salida de Lista de Espera, por ejemplo, en caso de defunción, GES, no beneficiario entre otras.

### Priorizador

Es el/la profesional clínico/a que ejerce las funciones de contraloría, quien debe dar prioridad a la solicitud de interconsulta, en función de la categorización definida, considerando patología, gravedad y determinantes sociales del paciente informadas por el profesional INICIADOR.

Este profesional pertenece al establecimiento secundario. También puede verificar si existe alguna causa de salida de Lista de Espera, por ejemplo, en caso de defunción, GES, no beneficiario, entre otras. (Según [Norma Técnica N°118](https://drive.google.com/file/d/1kZBAY7E-Rmy3DxGCMP3emotxEWh5nLEy/view)).

### Agendador

Es el funcionario administrativo encargado de agendar la cita para la consulta de especialidad en el nivel secundario, luego de que la SIC ha sido aprobada y priorizada. Para ello deberá contactar al usuario/a y asignar la hora según la disponibilidad de oferta de horas.

Este profesional puede pertenecer al establecimiento de atención primaria o secundaria, según lo definido por cada Servicio de Salud según acuerdo entre ambos niveles y el Servicio de Salud.

Este/a funcionario/a tambien puede verificar si existe alguna causa de salida de Lista de Espera, por ejemplo, en caso de defunción, GES, no beneficiario entre otras. (Según [Norma técnica N°118](https://drive.google.com/file/d/1kZBAY7E-Rmy3DxGCMP3emotxEWh5nLEy/view)).

### Atendedor

Es el profesional médico u odontólogo competente que dará la atención de especialidad al usuario/a (paciente) en el establecimiento de nivel secundario. Tendrá a la vista los datos de la Solicitud de Interconsulta generada en el establecimiento de nivel primario en la Ficha Clínica Electrónica local por el INICIADOR, y registrará los datos del encuentro médico (solicitud de exámenes, indicaciones, tratamiento, reposo, etc.) en el registro clínico electrónico del establecimiento de nivel secundario. Este profesional deberá generar como resultado de la atención, dejar al usuario/a (paciente) en control en el nivel secundario, en control en el nivel primario, hospitalizarlo, o dar de alta.

### Terminador

Corresponde al funcionario administrativo que ejecuta la salida del usuario/a paciente de lista de espera, en función de si recibió la atención de especialidad, o por alguna de las otras causales de eliminación de la Lista de Espera (Según [Norma Técnica N°118](https://drive.google.com/file/d/1kZBAY7E-Rmy3DxGCMP3emotxEWh5nLEy/view)).

En algunos casos esto podría ser automático, marcando como responsable al que gatilló el envio de este evento, según definiciones del sistema informático local.

